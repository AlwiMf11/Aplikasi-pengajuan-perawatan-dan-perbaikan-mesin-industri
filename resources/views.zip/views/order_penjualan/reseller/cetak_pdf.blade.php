<!DOCTYPE html>
<html>
<head>
	<title>Bukti Transaksi Penjualan</title>
</head>
<body>
    <style type="text/css">
    .table1 {
    font-family: sans-serif;
    color: #444;
    border-collapse: collapse;
    width: 100%;
    border: 1px solid #f2f5f7;
}

.table1 tr th{
    background: #35A9DB;
    color: #fff;
    font-weight: normal;
}
h2{
    color: grey;
    font-weight: bold;
}
.table1, th, td {
    padding: 8px 20px;
    text-align: center;
}

.table1 tr:hover {
    background-color: #f5f5f5;
}

.table1 tr:nth-child(even) {
    background-color: #f2f2f2;
}
		table tr td,
		table tr th{
			font-size: 11pt;
		}
	</style>
	<center>
		<h2>Bukti Transaksi Penjualan</h2>
    </center>
    <div class="tag">
    <p style="margin-left:20px;">No SO : {{$order->kd_transaksi_penjualan}} <span style="float:right; margin-right:30px;">Tanggal : {{$order->tgl_penjualan}}</span> </p>
    <p style="margin-left:20px;">Nama Pelanggan : {{$order->nama_pelanggan}} <span style="float:right; margin-right:30px;">Nama Reseller : {{$order->reseller->nama}}</span> </p>
    <p style="margin-left:20px;">Qty Barang : {{$order->qty_barang}} <span style="float:right; margin-right:30px;">Nilai Transaksi : @currency($order->nilai_transaksi)</span> </p>
    </div>

	<table class='table1'>
		<thead>
			<tr>
                <th>Nama Produk</th>
                <th>Kuantitas</th>
                <th>Harga</th>
                <th>Diskon (%)</th>
                <th>Sub Total</th>
			</tr>
		</thead>
		<tbody>
			@php $i=1 @endphp
            @foreach($orders as $value)
            <tr>
                <td>{{$value->produk->nama_produk}}</td>
                <td>{{$value->jumlah_penjualan}}</td>
                <td>@currency($value->harga_jual)</td>
                <td>{{$value->diskon}}</td>
                <td>@currency($value->sub_total)</td>
            </tr>
			@endforeach
            <tr>
                <td colspan="4" style="text-align:center !important;">Total</td>
                <td>@currency($orders->sum('sub_total'))</td>
            </tr>  
		</tbody>
        
	</table>
    
    <table class="table1">
        <tr>
            <th>Keterangan Order</th>
            <th>Tanda Tangan</th>
        </tr>
        <tr>
            <td>
                @if($order->keterangan_penjualan !='')
                {{$order->keterangan_penjualan}}
                @else
                -
                @endif
            </td>
            <td>
                @if($order->ttd !='')
                <img src="{{ public_path('database/ttd/reseller/'). $order->ttd}}" width="200" alt="BTS">
                @else
                -
                @endif
            </td>
        </tr>
        </table>

</body>
</html>