@extends('layouts.layout')
@section('content')
<title>Terima Order | Makan Daging</title>

<style>

@media screen and (min-width: 1024px) {
    .geser {
        margin-top: 100px;
    }
}

@media screen and (max-width: 729px) {
    .geser {
        margin-top: 50px;
    }
    
}

</style>
<div class="product-sales-area mg-tb-30 geser">
    <div class="data-table-area mg-b-15">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sparkline13-list">
                        <div class="sparkline13-hd">
                            <div class="main-sparkline13-hd">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h1>Data Order Pembelian</h1>
                                    </div>
                                </div>
                                <!-- <hr>

                                <button class='btn btn-custon-rounded-three btn-primary'><i class='fa fa-plus edu-informatio' aria-hidden='true'></i> Tambah Data</button></a>
                                <hr> -->
                                <hr>
                            </div>
                        </div>
                        <div class="sparkline13-graph">
                            <div class=" custom-datatable-overright table-responsive">
                                <table id="table" class="table table-striped table-bordered dt-responsive" style="width:100%">
                                    <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>No Purchase Order</th>
                                        <th>Tgl Order</th>
                                        <th>Tgl Diterima</th>
                                        <th>Nama Supplier</th>
                                        <th>Qty Barang</th>
                                        <th>Nilai PO</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@if(Auth::user()->level !='Admin')
@push('scripts')    
<script type="text/javascript">
    $(function() {
        var oTable = $('#table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ url("tambah_stok_server_side") }}',
            },
            columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex' },
            {data: 'kd_transaksi_pembelian', name: 'kd_transaksi_pembelian'},
            {data: 'tgl_pemesanan', name: 'tgl_pemesanan'},
            {data: 'tgl_pengiriman', name: 'tgl_pengiriman'},
            {data: 'nama_supplier', name: 'nama_supplier'},
            {data: 'qty_barang', name: 'qty_barang'},
            {data: 'nilai_transaksi', name: 'nilai_transaksi'},
            {data: 'status', name: 'status'},
        ],
        });
    });
    
</script>

@endpush
@else
@push('scripts')    
<script type="text/javascript">
    $(function() {
        var oTable = $('#table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ url("tambah_stok_server_side") }}',
            },
            columns: [
            // {data: 'rownum', name: 'rownum'},
            { data: 'DT_RowIndex', name: 'DT_RowIndex' },
            { data: 'kd_transaksi_pembelian', name: 'kd_transaksi_pembelian' },
            {data: 'tgl_pemesanan', name: 'tgl_pemesanan'},
            {data: 'tgl_pengiriman', name: 'tgl_pengiriman'},
            {data: 'nama_supplier', name: 'nama_supplier'},
            {data: 'qty_barang', name: 'qty_barang'},
            {data: 'nilai_transaksi', name: 'nilai_transaksi'},
            {data: 'status', name: 'status'},
            {data: 'action', name: 'action'},
        ],
        });
    });
    
</script>

@endpush
@endif