@extends('layouts.template')
@section('content')
<title>Lihat Transaksi | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6>Nama Pelanggan : {{$order->nama_pelanggan}}</h6>
            </div>
            <div class="col-md-6 text-right">
                <h6>No Purchase Order : {{$order->kd_transaksi_penjualan}} </h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nama Produk</th>
                        <th>Kuantitas</th>
                        <th>Harga</th>
                        <th>Diskon (%)</th>
                        <th>Sub Total</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($orders as $value)
                <tr>
                    <td>{{$value->produk->nama_produk}}</td>
                    <td>{{$value->jumlah_penjualan}}</td>
                    <td>@currency($value->harga_jual)</td>
                    <td>{{$value->diskon}}</td>
                    <td>@currency($value->sub_total)</td>
                </tr>
                    @endforeach
                    <tr>
                    <td colspan="4" style="text-align:center !important;">Total</td>
                    <td>@currency($orders->sum('sub_total'))</td>
                </tr> 
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
