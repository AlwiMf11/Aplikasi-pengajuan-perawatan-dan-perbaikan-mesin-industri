@extends('layouts.template')
@section('content')
<link rel="stylesheet" href="css/modals.css">
<!-- forms CSS
    ============================================ -->
<link rel="stylesheet" href="{{url('kialap/css/form/all-type-forms.css')}}">
<!-- summernote CSS
============================================ -->
<link rel="stylesheet" href="{{url('kialap/css/summernote/summernote.css')}}">
<title>Order Penjualan | Kelola Penjualan</title>
    @error('ttd')
        <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong> Gagal memproses ! File Tanda tangan harus berbentuk jpg,jpeg,png !</strong>
        </div>
    @enderror

    @error('nama_pelanggan')
        <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong> Gagal memproses ! Nama pelanggan harus diisi !</strong>
        </div>
    @enderror
<div class="card shadow mb-4">
    <div class="card-header py-3">
    </div>
    <div class="card-body">
        <div class="table-responsive">
        <form action="/masuk_keranjang/admin/store" method="post">
        @csrf
        <table class="table table-striped table-bordered dt-responsive" id="tb">
        <tr>
        <th>Nama Produk</th>
        <th>Stok Produk</th>
        <th>Harga</th>
        <th>Kuantitas</th>
        <th>Diskon (%)</th>
        <th>Aksi</th>
        <tr>
        <td>
        <select name="produk_id" id="produk_id" required class="form-control">
        <option value="" selected>~Pilih Produk~</option>
            @foreach($produk as $value)
                <option value="{{$value->id}}">{{$value->nama_produk}}</option>
            @endforeach
        </select>
        </td>   
        <td><input type="number" name="stok_reseller" id="stok_reseller" disabled required class="form-control"></td>
        <td> <input type="hidden" id="harga_awal" name="harga_awal"><input type="hidden" id="harga_akhir" name="harga_akhir">
        <input type="text" name="harga_jual" disabled id="harga_jual" required class="form-control">
        </td>
        <td><input type="number" name="kuantitas" id="kuantitas" min="1" onkeyup="hitung()" required class="form-control"></td>
        <td><input type="number" name="diskon" id="diskon" min="0" required class="form-control"></td>
        <td>
        <button class="btn btn-primary text-right" id="masuk_keranjang">Tambah</button>
        </td>
        </tr>

        </table>
        </form>
        </div>
    </div>
</div>
<form action="/kirim_order_admin" method="POST" id="form-semua" enctype="multipart/form-data">
        @csrf        
<div class="row">
    <div class="col-md-3">
        <label for="nama_pelanggan">Nama Pelanggan @error('nama_pelanggan') <span class="text-danger"> Harus diisi !</span> @enderror </label>
        <input type="text" name="nama_pelanggan" id="nama_pelanggan" value="{{old('nama_pelanggan')}}" class="form-control" required>
    </div>
    <div class="col-md-3">
        <label for="date">Tanggal</label>
        <input type="date" class="form-control" value="<?php echo date('Y-m-d');?>" disabled> 
    </div>
    
    <div class="col-md-3">
        <label for="kode_order">No. Purchase Order</label>
        <input type="text" class="form-control" value="{{$kd_transaksi}}" disabled> 
    </div>
</div>
<br>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="row">
            <div class="col-md-6">
                <h6>Order Produk</h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
        @csrf
        <table class="table table-striped table-bordered dt-responsive" id="tb">
        <tr>
        <th>Aksi</th>
        <th>Nama Produk</th>
        <th>Kuantitas</th>
        <th>Harga</th>
        <th>Diskon (%)</th>
        <th>Sub Total</th>
        @foreach($keranjang as $value)
            <tr>    
                <td><a href="/keranjang_admin/hapus/{{$value->id}}" class="btn btn-danger putih btn-block"> Batal</a></td>
                <td>{{$value->produk->nama_produk}}</td>
                <td>{{$value->jumlah_penjualan}}</td>
                <td>@currency($value->harga_jual)</td>
                <td>{{$value->diskon}}</td>
                <td>@currency($value->sub_total)</td>
            </tr>
        @endforeach
        @if($keranjang->count() == '')
        <tr>
            <td colspan="6" style="text-align:center">Belum Ada Order</td>
        </tr>
        @else
        <tr>
            <td colspan="5" style="text-align:center !important;">
                Total
            </td>
            <td>
                @currency($keranjang->sum('sub_total'))
            </td>
        </tr>
        @endif
        </table>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group">
                    <label for="keterangan">Keterangan</label>
                    <textarea name="keterangan" id="keterangan" cols="30" rows="2" class="form-control">

                    </textarea>
                </div>
            </div>
            <div class="col-lg-6">
                <label for="ttd" style="margin-left:12px;">Tanda Tangan dan Materai ( Optional )</label>
                <div class="form-group-inner">  
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="file-upload-inner file-upload-inner-right ts-forms">
                            <div class="input append-small-btn">
                                <div class="file-button">
                                    Browse
                                    <input name="ttd" type="file" onchange="document.getElementById('append-small-btn').value = this.value;">
                                </div>
                                <input name="ttd" type="text" id="append-small-btn" placeholder="no file selected">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <input type="hidden" name="nilai_transaksi" value="{{$keranjang->sum('sub_total')}}">
                <input type="hidden" name="digit" value="{{$digit}}">
                <input type="hidden" name="nilai_transaksi" value="{{$keranjang->sum('sub_total')}}">
                @if($keranjang->count() == 0)
                <a href="javascript:void(0)" title="keranjang order masih kosong" disabled class="btn btn-primary">Simpan</a>
                @else
                <button name="simpan" id="simpan" class="btn btn-primary">Simpan</button>
                </form>
                @endif
                <a href="/order_penjualan_admin" class="btn btn-danger">Kembali</a>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- summernote JS
============================================ -->
<script src="{{url('kialap/js/summernote/summernote.min.js')}}"></script>
<script src="{{url('kialap/js/summernote/summernote-active.js')}}"></script>


<!-- dropzone CSS
============================================ -->
<link rel="stylesheet" href="{{url('kialap/css/dropzone/dropzone.css')}}">

<!-- dropzone JS
============================================ -->
<script src="{{url('kialap/js/dropzone/dropzone.js')}}"></script>

<script>

function diskons()
  {
    var harga_awal = $('#harga_awal').val();
    var harga_akhir = $('#harga_akhir').val();
    var harga_jual = $('#harga_jual').val();
    var kuantitas = $('#kuantitas').val();
    if(diskon ==  '')
    {
        var a = harga_jual * kuantitas;
        $('#harga_jual').val(a);
        $('#harga_akhir').val(a);
    }
    else
    {
    var a = (harga_jual * kuantitas * 10) / 100;
    $('#harga_jual').val(a);
    $('#harga_akhir').val(a);
    }

  }


function hitung()
  {
    var stok_reseller = $('#stok_reseller').val();
    var harga_awal = $('#harga_awal').val();
    var harga_akhir = $('#harga_akhir').val();
    var harga_jual = $('#harga_jual').val();
    var kuantitas = $('#kuantitas').val();
    if(kuantitas ==  '')
    {
        var a = harga_awal;
        $('#harga_jual').val(a);
        $('#harga_akhir').val(a);
    }
    else
    {
        if(parseInt(kuantitas) > stok_reseller)
        {        
            $("#masuk_keranjang").prop("disabled", true);
            document.getElementById("masuk_keranjang").title = "Stok tidak cukup";
        }
        else
        {
            var a = parseInt(harga_jual) * parseInt(kuantitas);
            $('#harga_jual').val(a);
            $('#harga_akhir').val(a);
            $("#masuk_keranjang").prop("disabled", false);
        }
    }

  }
  

function disabled()
{
    $("#kuantitas").prop("disabled", true);
}

$(function(){
    
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});

    $('#addMore').on('click', function() {
              var data = $("#tb tr:eq(1)").clone(true).appendTo("#tb");
              data.find("input").val('');
     });
     $(document).on('click', '.remove', function() {
         var trIndex = $(this).closest("tr").index();
            if(trIndex>1) {
             $(this).closest("tr").remove();
           } else {
             alert("Sorry!! Can't remove first row!");
           }
      });
});     



$('#produk_id').change(function(){
    $("#kuantitas").prop("disabled", false);
    var produk_id = $(this).val();    
    if(produk_id){
        $.ajax({
           type:"GET",
           url:"{{url('ambil_harga_jual_admin')}}?id="+produk_id,
           success:function(res){               
            if(res){
                $.each(res,function(key,stok){
                    $("#harga_awal").val(key);
                    $("#harga_jual").val(key);
                    $("#stok_reseller").val(stok);
    $("#diskon").val(0);
                });
           
            }else{
                    $("#deskripsi_produk").empty();
                    $("#harga_jual").empty();
                    $("#stok_reseller").empty();
                    $("#diskon").val();
            }
           }
        });
    }else{
                    $("#deskripsi_produk").empty();
                    $("#harga_jual").empty();
                    $("#stok_reseller").empty();
                    $("#diskon").val();
       
    }      
});


var form = document.getElementById("form-semua");

document.getElementById("simpan").addEventListener("click", function () {
  form.submit();
    $('#simpan').attr("disabled", true);
});

</script>
@endpush