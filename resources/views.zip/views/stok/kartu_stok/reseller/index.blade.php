@extends('layouts.template')
@section('content')
<title>Kartu Stok | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Kartu Stok</h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Harga Jual</th>
                        <th>Harga Beli</th>
                        <th>Satuan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($produk as $i => $value)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$value->produk->nama_produk}}</td>
                        <td>{{$value->produk->kategori->nama_kategori}}</td>
                        <td>{{$value->stok_reseller}}</ td>
                        <td>{{$value->harga_jual}}</td>
                        <td>{{$value->produk->harga_jual}}</td>
                        <td>{{$value->produk->satuan->nama_satuan}}</td>
                        <td>
                        <a href="/kartu_stok_reseller/lihat/{{$value->id}}" class="btn btn-primary btn-sm">Lihat</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
