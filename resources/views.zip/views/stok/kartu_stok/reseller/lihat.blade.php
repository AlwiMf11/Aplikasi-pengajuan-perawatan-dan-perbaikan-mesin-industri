@extends('layouts.template')
@section('content')
<title>Detail Kartu Stok Barang | Kelola Penjualan</title>
<form action="/kartu_stok_reseller/excel" method="post">
            @csrf
            <input type="hidden" value="{{$produk_id}}" name="produk_id">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Dari Tanggal</label>
                        @if(request('tanggal1') != '')
                        <input type="date" name="tanggal1" required class="form-control" value="{{request('tanggal1')}}" >
                        @else
                        <input type="date" name="tanggal1" required class="form-control">
                        @endif
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Sampai Tanggal</label>
                        @if(request('tanggal2') != '')
                        <input type="date" name="tanggal2" required class="form-control" value="{{request('tanggal2')}}" >
                        @else
                        <input type="date" name="tanggal2" required class="form-control">
                        @endif
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label style="color: #F6F8FA !important;">Sampai Tanggal</label> <br>
                        <input type="submit" class="btn btn-primary">
                    </form>
                    </div>
                </div>
            </div>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Detail Kartu Stok Barang</h6>
            </div>                  
            <div class="col-md-6 text-right">
            @if(request('tanggal1') != '')
            <form action="/kartu_stok/reseller/export_excel" method="get">
                <input type="hidden" name="produk_id" value="{{$produk_id}}">
                <input type="hidden" name="tanggal1" value="{{$req1}}">
                <input type="hidden" name="tanggal2" value="{{$req2}}">
                <input type="hidden" name="status_bayar" value="{{$req3}}">
                <input type="submit" class="btn btn-success" value="EXPORT EXCEL">
            </form>
            @else
            <form action="/kartu_stok/reseller/export_excel" method="get">
                <input type="hidden" name="produk_id" value="{{$produk_id}}">
                <input type="submit" class="btn btn-success" value="EXPORT EXCEL">
            </form>
            @endif
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                        <th>Nama Produk</th>
                        <th>Db</th>
                        <th>Kr</th>
                        <th>Saldo</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($kartu_stok as $no => $value)
                        <tr>
                            <td>{{++$no}}</td>
                            <td>{{$value->tgl}}</td>
                            <td>{{$value->keterangan}}</td>
                            <td>{{$value->produk->nama_produk}}</td>
                            <td>{{$value->db}}</td>
                            <td>{{$value->kr}}</td>
                            <td>{{$value->saldo}}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
