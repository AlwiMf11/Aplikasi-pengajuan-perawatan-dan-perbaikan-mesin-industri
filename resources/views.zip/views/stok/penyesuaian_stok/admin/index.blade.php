@extends('layouts.template')
@section('content')
<title>History Penyesuaian Stok  | Kelola Penjualan</title>
<form action="/penyesuaian_stok_admin/filter" method="get">
            @csrf
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Dari Tanggal</label>
                        @if(request('tanggal1') != '')
                        <input type="date" name="tanggal1" required class="form-control" value="{{request('tanggal1')}}" >
                        @else
                        <input type="date" name="tanggal1" required class="form-control">
                        @endif
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Sampai Tanggal</label>
                        @if(request('tanggal2') != '')
                        <input type="date" name="tanggal2" required class="form-control" value="{{request('tanggal2')}}" >
                        @else
                        <input type="date" name="tanggal2" required class="form-control">
                        @endif
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label style="color: #F6F8FA !important;">Sampai Tanggal</label> <br>
                        <input type="submit" class="btn btn-primary">
                    </form>
                    </div>
                </div>
            </div>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">              
            @if(Auth::user()->level !='Admin')
            @else
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Data Penyesuaian Stok</h6>
            </div>
            @endif                         
            <div class="col-md-6 text-right">
                <a href="/penyesuaian_stok_admin/tambah" class="btn btn-primary btn-sm">Tambah Data</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
        @if(request('tanggal1') != '')
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Nama Produk</th>
                    <th>Qty</th>
                    <th>Tipe</th>
                    <th>Action</th>
                </tr>
                <tbody>
                @foreach($data as $key=> $value)
                <tr>
                    <td>{{++$key}}</td>
                    <td>{{$value->tgl}}</td>
                    <td>{{$value->produk->nama_produk}}</td>
                    <td>{{$value->qty}}</td>
                    <td>{{$value->tipe}}</td>
                    <td><a href="/penyesuaian_stok_admin/hapus/{{$value->id}}" onclick="return confirm('Apakah anda ingin menghapus data tersebut ?')" class="btn btn-custon-rounded-two btn-danger btn-sm btn-xs" style="color:white">Hapus</a></td>
                </tr>
                @endforeach
                </tbody>
            </table>
        @else
            <table id="dataTable" class="table table-bordered" cellspacing="0">
            <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Nama Produk</th>
                <th>Qty</th>
                <th>Tipe</th>
                <th>Action</th>
            </tr>
            <tbody>
            @foreach($data as $key => $value)
            <tr>
                <td>{{++$key}}</td>
                <td>{{$value->tgl}}</td>
                <td>{{$value->produk->nama_produk}}</td>
                <td>{{$value->qty}}</td>
                <td>{{$value->tipe}}</td>
                <td><a href="/penyesuaian_stok_admin/hapus/{{$value->id}}" onclick="return confirm('Apakah anda ingin menghapus data tersebut ?')" class="btn btn-custon-rounded-two btn-danger btn-sm btn-xs" style="color:white">Hapus</a></td>
            </tr>
            @endforeach
            </tbody>
        </table>
        @endif
        </div>
    </div>
</div>

@endsection
