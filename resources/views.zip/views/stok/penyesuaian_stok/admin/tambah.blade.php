@extends('layouts.template')
@section('content')
<title>Penyesuaian Stok | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Penyesuaian Stok</h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
        <form action="/penyesuaian_stok_admin/store" method="post">
        @csrf
        <table class="table table-striped table-bordered dt-responsive" id="tb">
        <tr>
        <th>Nama Produk</th>
        <th>Quantity</th>
        <th>Tipe</th>
        <th><a href="javascript:void(0);" style="font-size:18px;" id="addMore" title="Add More Person"><span class="fas fa-plus"></span></a></th>
        <tr>
        <td>
        <select name="produk_id[]" required class="form-control">
        <option value="" selected>~Pilih Produk~</option>
            @foreach($produk as $value)
                <option value="{{$value->id}}">{{$value->nama_produk}}</option>
            @endforeach
        </select>
        </td>
        <td><input type="number" name="qty[]" required class="form-control"></td>
        <td>
        <select name="tipe[]" required class="form-control">
        <option value="" selected>~Tipe~</option>
            <option value="Tambah">Tambah</option>
            <option value="Kurang">Kurang</option> 
        </select>
        </td>
        <td><a href='javascript:void(0);'  class='text-danger remove'><span class='fas fa-trash'></span></a></td>
        
        </tr>
        </table>
        <button class="btn btn-primary text-right">Simpan</button>
        </form>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script>
$(function(){
    
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});

    $('#addMore').on('click', function() {
              var data = $("#tb tr:eq(1)").clone(true).appendTo("#tb");
              data.find("input").val('');
     });
     $(document).on('click', '.remove', function() {
         var trIndex = $(this).closest("tr").index();
            if(trIndex>1) {
             $(this).closest("tr").remove();
           } else {
             alert("Sorry!! Can't remove first row!");
           }
      });
});      
</script>
@endpush