@extends('layouts.layout')
@section('content')
<title>Order Pembelian | Makan Daging</title>

<!-- Font Awesome -->
<link rel="stylesheet" href="{{url('/assets/adminlte/plugins/fontawesome-free/css/all.min.css')}}">
<!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="{{url('/assets/adminlte/dist/css/adminlte.min.css')}}">
<!-- summernote -->
<link rel="stylesheet" href="{{url('/assets/adminlte/plugins/summernote/summernote-bs4.css')}}">
<!-- Google Font: Source Sans Pro -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
<style>

@media screen and (min-width: 1024px) {
    .geser {
        margin-top: 100px;
    }
}

@media screen and (max-width: 729px) {
    .geser {
        margin-top: 50px;
    }
    
}
textarea {
  width: 300px;
  height: 40px !important;
}

</style>

<div class="product-sales-area mg-tb-30 geser">
    <div class="data-table-area mg-b-15">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sparkline13-list">
                        <div class="sparkline13-graph">
                            <div class=" custom-datatable-overright table-responsive">
                            <form action="/masuk_keranjang/store" method="post">
                            @csrf
                            <table class="table table-striped table-bordered dt-responsive" id="tb">
                            <tr>
                            <th>Nama Produk</th>
                            <th>Deskripsi</th>
                            <th>Harga</th>
                            <th>Kuantitas</th>
                            <th>Aksi</th>
                            <tr>
                            <td>
                            <select name="produk_id" id="produk_id" required class="form-control">
                            <option value="" selected>~Pilih Produk~</option>
                                @foreach($produk as $value)
                                    <option value="{{$value->id}}">{{$value->nama_produk}}</option>
                                @endforeach
                            </select>
                            </td>
                            <td>
                            <textarea name="deskripsi_produk" id="deskripsi_produk" disabled class="form-control" required></textarea>
                            </td>
                            <td><input type="text" name="harga_beli" disabled id="harga_beli" required class="form-control"></td>
                            <td><input type="number" name="kuantitas" id="kuantitas" min="1" onkeyup="hitung()" required class="form-control"></td>
                            <td>
                            <button class="btn btn-primary text-right">Tambah</button>
                            </td>
                            </tr>

                            </table>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<br>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sparkline13-list">
                        <div class="sparkline13-hd">
                            <div class="main-sparkline13-hd">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h1>Order Produk</h1>
                                    </div>
                                </div>
                                <hr>                                
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="admin_id">Pemasok</label>
                                        <select name="admin_id" id="admin_id" class="form-control" disabled>
                                            <option value="1">MakanDaging.com</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="date">Tanggal</label>
                                        <input type="date" class="form-control" value="<?php echo date('Y-m-d');?>" disabled> 
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <label for="kode_order">No. Purchase Order</label>
                                        <input type="text" class="form-control" value="{{$kd_transaksi}}" disabled> 
                                    </div>
                                </div>
                                
                                <!-- <hr>

                                <button class='btn btn-custon-rounded-three btn-primary'><i class='fa fa-plus edu-informatio' aria-hidden='true'></i> Tambah Data</button></a>
                                <hr> -->
                                <hr>
                            </div>
                        </div>
                        <div class="sparkline13-graph">
                            <div class=" custom-datatable-overright table-responsive">
                            <form action="/order_pembelian_selesai/store" method="post">
                            @csrf
                            <table class="table table-striped table-bordered dt-responsive" id="tb">
                            <tr>
                            <th>Aksi</th>
                            <th>Nama Produk</th>
                            <th>Deskripsi</th>
                            <th>Harga</th>
                            <th>Kuantitas</th>
                            <th>Sub Total</th>
                            @foreach($keranjang as $value)
                                <tr>    
                                    <td><a href="/keranjang_hapus/{{$value->id}}" class="btn btn-danger btn-block"><i class="fas fa-crash"></i> Batal</a></td>
                                    <td>{{$value->produk->nama_produk}}</td>
                                    <td>{{$value->produk->deskripsi_produk}}</td>
                                    <td>{{$value->produk->harga_beli}}</td>
                                    <td>{{$value->jumlah_pesanan}}</td>
                                    <td>{{$value->sub_total}}</td>
                                </tr>
                            @endforeach
                            
                            <tr>
                                <td colspan="5">
                                    Total
                                </td>
                                <td>
                                    {{$keranjang->sum('sub_total')}}
                                </td>
                            </tr>
                            </table>
                            <div class="row">
                                <div class="col-lg-3"><!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-outline card-info">
            <div class="card-header">
              <h3 class="card-title">
                Bootstrap WYSIHTML5
                <small>Simple and fast</small>
              </h3>
              <!-- tools box -->
              <div class="card-tools">
                <button type="button" class="btn btn-tool btn-sm" data-card-widget="collapse" data-toggle="tooltip"
                        title="Collapse">
                  <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool btn-sm" data-card-widget="remove" data-toggle="tooltip"
                        title="Remove">
                  <i class="fas fa-times"></i></button>
              </div>
              <!-- /. tools -->
            </div>
            <!-- /.card-header -->
            <div class="card-body pad">
              <div class="mb-3">
                <textarea class="textarea" placeholder="Place some text here"
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
              </div>
              <p class="text-sm mb-0">
                Editor <a href="https://github.com/bootstrap-wysiwyg/bootstrap3-wysiwyg">Documentation and license
                information.</a>
              </p>
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
    </section>
                                <div class="col-lg-6 text-right pull-leff-1">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4>Total <span></span> </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection

@push('scripts')

<!-- jQuery -->
<script src="{{url('assets/adminlte/plugins/jquery/jquery.min.js')}}"></script>
<!-- Bootstrap 4 -->
<script src="{{url('assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{url('assets/adminlte/dist/js/adminlte.min.js')}}"></script>
<!-- AdminLTE for demo purposes -->
<script src="{{url('assets/adminlte/dist/js/demo.js')}}"></script>
<!-- Summernote -->
<script src="{{url('assets/adminlte/plugins/summernote/summernote-bs4.min.js')}}"></script>
<script>
  $(function () {
    // Summernote
    $('.textarea').summernote()
  })
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script>



function hitung()
  {
    var harga_beli = $('#harga_beli').val();
    var kuantitas = $('#kuantitas').val();
    var a = harga_beli * kuantitas;
    $('#harga_beli').val(a);

  }

$(function(){
    
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});

    $('#addMore').on('click', function() {
              var data = $("#tb tr:eq(1)").clone(true).appendTo("#tb");
              data.find("input").val('');
     });
     $(document).on('click', '.remove', function() {
         var trIndex = $(this).closest("tr").index();
            if(trIndex>1) {
             $(this).closest("tr").remove();
           } else {
             alert("Sorry!! Can't remove first row!");
           }
      });
});     



$('#produk_id').change(function(){
    var produk_id = $(this).val();    
    if(produk_id){
        $.ajax({
           type:"GET",
           url:"{{url('ambil2')}}?id="+produk_id,
           success:function(res){               
            if(res){
                $.each(res,function(key,value){
                    $("#deskripsi_produk").val(value);
                    $("#harga_beli").val(key);
                });
           
            }else{
                    $("#deskripsi_produk").empty();
                    $("#harga_beli").empty();
            }
           }
        });
    }else{
                    $("#deskripsi_produk").empty();
                    $("#harga_beli").empty();
       
    }      
});


// function tambahBtnOnclick() {
//     document.getElementById("kuantitas").value = Number(document.getElementById("kuantitas").value) + 1;
    
//     var kuantitas = $('#kuantitas').val();
//     var harga_beli = $('#harga_beli').val();
//     var a = kuantitas * harga_beli;
//     $('#harga_beli').val(a);
// }

// function kurangBtnOnclick() {
//     var harga_beli = $('#harga_beli').val();
//     if(harga_beli === 1)
//     {
//         return false;
//     }
//     else
//     {
//         document.getElementById("kuantitas").value = Number(document.getElementById("kuantitas").value) - 1;
//     }
//     var kuantitas = $('#kuantitas').val();
//     var a = kuantitas * harga_beli;
//     $('#harga_beli').val(a);
// }
</script>
@endpush