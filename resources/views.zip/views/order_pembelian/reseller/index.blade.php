@extends('layouts.template')
@section('content')
<title>Order Pembelian | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Data Order Pembelian</h6>
            </div>
            <div class="col-md-6 text-right">
                <a href="/order_pembelian/reseller/tambah" class="btn btn-custon-rounded-three btn-primary btn-sm"> <i class="fa fa-plus"></i> Buat Purchase Order Baru</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>No Purchase Order</th>
                        <th>Tgl Pemesanan</th>
                        <th>Qty Barang</th>
                        <th>Nilai PO</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($transaksi_pembelian as $i => $value)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$value->kd_transaksi_pembelian}}</td>
                        <td>{{$value->tgl_pemesanan}}</td>
                        <td>{{$value->qty_barang}}</td>
                        <td>{{$value->nilai_transaksi}}</td>
                        <td>{{$value->status_order}}</td>
                        <td>
                        @if($value->status_order == 'terkirim')
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-list"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a href="/pembelian_reseller/lihat/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Lihat</a>
                        <a href="/pembelian_reseller/cetak/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Cetak</a>
                            </div>
                        </div>
                        @elseif($value->status_order == 'dikirim')
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-list"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a href="/pembelian_reseller/update/{{$value->kd_transaksi_pembelian}}" onclick="return confirm(\'Anda yakin untuk menerima pesanan ? \');" class="dropdown-item">Terima</a>
                            <a href="/pembelian_reseller/lihat/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Lihat</a>
                            <a href="/pembelian_reseller/cetak/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Cetak</a>
                            </div>
                        </div>
                        
                        @elseif($value->status_order == 'diterima')
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-list"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a href="/pembelian_reseller/lihat/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Lihat</a>
                            <a href="/pembelian_reseller/cetak/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Cetak</a>
                            </div>
                        </div>
                        @elseif($value->status_order == 'pending')
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-list"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a href="/pembelian_reseller/lihat/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Lihat</a>
                            <a href="/pembelian_reseller/cetak/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Cetak</a>
                            </div>
                        </div>
                        @endif
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
