@extends('layouts.template')
@section('content')
<style>
    
input[type=file]{
}

#idfoto{
    background-image:url('');
    background-size:cover;
    background-position: center;
    height: 100px; 
    width: 100px;
    border: 1px solid #bbb;
}

</style>
<title>Tambah Supplier | Kelola Penjualan</title>
@if( Session::get('gagal') !="")
            <div class='alert alert-danger'><center><b>{{Session::get('gagal')}}</b></center></div>        
@endif
    @error('gambar')
    <div class="col-sm-12">
        <div class="col-sm-12">
            <div class="alert bg-danger">
                <strong class="text-white"> Gambar Produk Harus Berbentuk JPG / JPEG / PNG</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    @enderror 
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Supplier</h6>
    </div>
    <div class="card-body">
    <form action="/supplier/store" method="post" enctype="multipart/form-data">
        @csrf
        
            <div class="form-group">
                <label for="">Username  @error('username') <span class="text-danger"> Username tersebut telah digunakan oleh user lain ! </span> @enderror </label>
                <input type="text" name="username" class="form-control" value="{{old('username')}}" required>
            </div>
            <div class="form-group">
                <label for="">Nama  @error('nama') <span class="text-danger">{{$message}} </span> @enderror </label>
                <input type="text" name="nama" class="form-control" value="{{old('nama')}}" required>
            </div>
            <div class="form-group">
                <label for="">Alamat @error('alamat') <span class="text-danger">{{$message}} </span> @enderror </label>
                <input type="text" name="alamat" class="form-control" value="{{old('alamat')}}" required>
            </div>
            <div class="form-group">
                <label for="">No Telp</label>
                <input type="number" name="no_telp" class="form-control" value="{{old('no_telp')}}" required>
            </div>
            <div class="form-group">
                <label for="">Email @error('email') <span class="text-danger">Email sudah digunakan oleh user lain </span> @enderror</label>
                <input type="email" name="email" class="form-control" value="{{old('email')}}" required>
            </div>
            <div class="form-group">
                <label for="">Foto @error('foto')<div class='alert alert-danger'><center><b>Gagal upload foto, File harus berbentuk jpg/png/jpeg</b></center></div>@enderror</label>
                <input type="file" name="foto" class="form-control" required>
            </div>

            <hr>
            <div class="row">
                <div class="col-lg-3">
                        <button class='btn btn-custon-rounded-three btn-primary' name="tambah" type="submit"><i class='fa fa-file-text edu-informatio' aria-hidden='true'></i> Simpan</button>
                        <button class='btn btn-custon-rounded-three btn-danger' type="reset" value="Reset" onClick="javascript:history.back()"><i class='fa fa-times-circle edu-informatio' aria-hidden='true'></i> Batal</button>
                </div>
            </div>
            <hr>
        </form>
    </div>
</div>

@push('scripts')

<script>

document.getElementById('foto').addEventListener('change', readURL, true);
function readURL(){
   var file = document.getElementById("foto").files[0];
   var reader = new FileReader();
   reader.onloadend = function(){
      document.getElementById('idfoto').style.backgroundImage = "url(" + reader.result + ")";        
   }
   if(file){
      reader.readAsDataURL(file);
    }else{
    }
}

</script>
@endpush
@endsection