
@extends('layouts.template')
@section('content')
<title>Edit Akun | Kelola Penjualan</title>

@if ($message = Session::get('error_akun'))
                <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong>{{ $message }}</strong>
                </div>
            @endif
            
            @if ($message = Session::get('error_password'))
                <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong>{{ $message }}</strong>
                </div>
            @endif
<div class="row">
    <div class="col-lg-6">
        <form action="/ubah_akun" method="post" enctype="multipart/form-data" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload">
            @csrf
            <input required type="hidden" class="form-control" placeholder="nama" name="id" value="{{$data->id}}">
        <div class="card">
            <div class="card-header">
                Edit Akun
            </div>
            <div class="card-body">
                <label for="nama">Nama : @error('nama') <span class="text-danger">{{$message}} <span> @enderror</label>
                <div class="form-group">
                    <input type="text" name="nama" value="{{$data->nama}}" class="form-control">
                </div>
                <label for="username">Username : @error('username') <span class="text-danger">{{$message}} <span> @enderror</label>
                <div class="form-group">
                    <input type="text" name="username" value="{{$data->username}}" class="form-control">
                </div>
                <hr>
                <div class="row">
                    <div class="col-lg-12">
                        <button class='btn btn-custon-rounded-three btn-primary' type="submit">Simpan</button>
                        <a  class='btn btn-custon-rounded-three btn-danger' href="/my_profile">Kembali</a>
                    </div>
                </div>
                <hr>
            </div>
        </div>
        </form>
    </div>
    
    <div class="col-lg-6">
        <form action="{{ route('change.password') }}" method="post" enctype="multipart/form-data" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload">
            @csrf 
            <input required type="hidden" class="form-control" placeholder="nama" name="id" value="{{$data->id}}">
        <div class="card">
            <div class="card-header">
                Ubah Password
            </div>
            <div class="card-body">
                <label for="current_password">Password Lama : @error('current_password') <span class="text-danger">Password lama yang Anda masukkan salah <span> @enderror</label>
                <div class="form-group">
                    <input required type="password" class="form-control" name="current_password">
                </div>
                
                <label for="new_password">Password Baru : @error('new_password') <span class="text-danger"><span> @enderror</label>
                <div class="form-group">
                    <input required type="password" class="form-control" name="new_password">
                </div>

                
                <label for="new_confirm_password">Konfirmasi Password Baru : @error('new_confirm_password') <span class="text-danger">Konfirmasi password tidak sesuai<span> @enderror</label>
                <div class="form-group">
                    <input required type="password" class="form-control" name="new_confirm_password">
                </div>

                <hr>
                <div class="row">
                    <div class="col-lg-12">
                        <button class='btn btn-custon-rounded-three btn-primary' type="submit">Simpan</button>
                        <a  class='btn btn-custon-rounded-three btn-danger' href="/my_profile">Kembali</a>
                    </div>
                </div>
                <hr>
            </div>
        </div>
        </form>
    </div>
    
</div>

@endsection

@push('scripts')
@endpush