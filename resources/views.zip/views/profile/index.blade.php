@extends('layouts.template')
@section('content')
<title>My Profile | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">My Profile</h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Nama Pegawai</th>
                    <th>No Telp</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $no = 0;?>
                @if(Auth::user()->level !='Reseller')
                @foreach($data as $value)
                <?php $no++;?>
                <tr>
                    <td>{{$no}}</td>
                    <td>{{$value->username}}</td>
                    <td>{{$value->nama}}</td>
                    <td>{{$value->no_telp}}</td>
                    <td>
                        <a href="/my_profile_lihat/{{$value->id}}" class='btn btn-custon-rounded-two btn-primary putih btn-sm'> View</a> | 
                        <a href="/my_profile_edit/{{$value->id}}" class='btn btn-custon-rounded-two btn-success putih btn-sm'>Edit</a>
                    </td>
                </tr>
                @endforeach
                @else
                @foreach($data as $value)
                <?php $no++;?>
                <tr>
                    <td>{{$no}}</td>
                    <td>{{$value->username}}</td>
                    <td>{{$value->reseller->nama}}</td>
                    <td>{{$value->reseller->no_telp}}</td>
                    <td>
                        <a href="/my_profile_lihat/{{$value->id}}" class='btn btn-custon-rounded-two btn-primary putih btn-sm'>View</a> | 
                        <a href="/my_profile_edit/{{$value->id}}" class='btn btn-custon-rounded-two btn-success putih btn-sm'>Edit</a>
                    </td>
                </tr>
                @endforeach
                @endif
                </tbody>
            </table>
            </table>
        </div>
    </div>
</div>

@endsection
