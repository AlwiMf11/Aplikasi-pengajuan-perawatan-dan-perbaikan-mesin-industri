@extends('layouts.template')
@section('content')
<title>Detail My Profile | Kelola Penjualan</title>
<style>

.atas{
    margin-top: -120px;
    margin-right:90px !important;
}

.atas-dikit{
    margin-top: -30px;
}
#upload{
    display:none
}

@media screen and (min-width: 1024px) {
    .geser {
        margin-top: 100px;
    }
}

@media screen and (max-width: 729px) {
    .geser {
        margin-top: 50px;
    }
    
}
.putih{
    color: white !important;
    font-size: 12px !important;
}

</style>
<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
            @if($data->foto == null)
            <img src="{{url('/database/foto_profil//avatar-2.png')}}" alt="AdminLTE Logo" style='width:260px; height: 270px;'>
            @else
            <img src="{{url('/database/foto_profil/'.$data->foto)}}" alt="" style='width:260px; height: 270px;'>
            @endif
            </div>
            <div class="row justify-content-center">
                <p>
                    <form action="/profil_foto_ubah" method="post" enctype="multipart/form-data" class="ml-5">
                        @csrf
                        <input type="hidden" name="id" value="{{$data->id}}">
                        <input id="upload" type="file" onchange="this.form.submit()" name="foto"/>
                        <a href="" id="upload_link" class="btn btn-primary bg-gradient-primary opacity-8 text-white btn-sm atas" style="margin-right:100px;">Ubah</a>​
                        @if($data->foto == null)
                        <button class="btn btn-danger btn-sm delete-confirm mr-5 atas" disabled>Hapus</button>
                        @else
                        <a href="/profil_foto_hapus/{{$data->id}}" class="btn btn-danger btn-sm delete-confirm mr-5 atas">Hapus</a>​
                        @endif
                    </form>
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-8 ">
        <div class="card">
            <div class="card-header">
                <h6>Detail Data Reseller</h6>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" value="{{$data->nama}}">
                </div>
                <div class="form-group">
                    <label for="alamat">Alamat</label>
                    <input type="text" class="form-control" value="{{$data->alamat}}">
                </div>
                <div class="form-group">
                    <label for="no_telp">No Telp</label>
                    <input type="text" class="form-control" value="{{$data->no_telp}}">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" value="{{$data->email}}">
                </div>
            </div>
        </div>
    </div>
</div>

<br>
@endsection


@push('scripts')
<script>

$(function(){
    $("#upload_link").on('click', function(e){
        e.preventDefault();
        $("#upload:hidden").trigger('click');
    });
});

</script>
@endpush