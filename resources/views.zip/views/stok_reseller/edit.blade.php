@extends('layouts.template')
@section('content')
<style>
    
.atur{
   height: 250px;
      width: 250px;
}
input[type=file]{
}

</style>
<title>Edit Stok | Kelola Penjualan</title>

@if( Session::get('gagal') !="")
    <div class='alert alert-danger'><center><b>{{Session::get('gagal')}}</b></center></div>        
    @endif
    @error('gambar')
    <div class="col-sm-12">
        <div class="col-sm-12">
            <div class="alert bg-danger">
                <strong class="text-white"> Gambar Produk Harus Berbentuk JPG / JPEG / PNG</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    @enderror 
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Data</h6>
    </div>
    <div class="card-body">
          <!-- awal form -->
          <form action="/stok_reseller/update" method="post" enctype="multipart/form-data">
                                        @csrf
                                        @foreach($produk as $value)
                                        <input type="hidden" name="id" value="{{$value->id}}">
                                        <div class="form-group">
                                                <label for="">Nama Produk @error('nama_produk') Nama produk tersebut telah digunakan @enderror</label>
                                                <input type="text" name="nama_produk" class="form-control" value="{{$value->produk->nama_produk}}"  required>
                                            </div>
                                            <div class="form-group">
                                                <label for="">Harga Beli</label>
                                                <input type="hidden" name="harga_awal" id="harga_awal" value="{{$value->produk->harga_jual}}">
                                                <input type="number" name="harga_jual" id="harga_jual_distributor" class="form-control" value="{{$value->produk->harga_jual}}"  disabled >
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="">Harga Jual</label>
                                                <input type="number" name="harga_jual" id="harga_jual" class="form-control" value="{{$value->harga_jual}}" required onkeyup="untung()">
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="">Margin</label>
                                                <input type="number" name="margin" id="margin" class="form-control" required disabled>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                        <button class='btn btn-custon-rounded-three btn-primary' type="submit"><i class='fa fa-file-text edu-informatio' aria-hidden='true'></i> Update</button>
                                        </form>
                                                        <a class='btn btn-custon-rounded-three btn-danger' href="/stok_reseller" value="Reset" onClick="javascript:history.back()"><i class='fa fa-times-circle edu-informatio' aria-hidden='true'></i> Kembali</a>
                                                </div>
                                            </div>
                                            <hr>
                                        @endforeach
    </div>
</div>

@endsection
@push('scripts')

<!-- chosen JS
============================================ -->
<script src="{{url('kialap/js/chosen/chosen.jquery.js')}}"></script>
<script src="{{url('kialap/js/chosen/chosen-active.js')}}"></script>
<script>
 function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
<script type="text/javascript">
    function ShowHideDiv() {
        var chkYes = document.getElementById("chkYes");
        var hilang = document.getElementById("hilang");
        var dvPassport = document.getElementById("dvPassport");
        if(chkYes.checked)
        {
            dvPassport.style.display = "block";
            hilang.style.display = "block";
            dvPassport.required = true;
        }
        else
        {
            dvPassport.style.display = "none";
            hilang.style.display = "none";
            dvPassport.required = false;
        }
        
    }

    


function hitung()
  {
    var harga_jual_distributor = $('#harga_jual_distributor').val();
    var harga_jual = $('#harga_jual').val();
    var margin = $('#margin').val();
    var a = harga_jual - harga_jual_distributor;
    $('#margin').val(a);

  }
  

function untung()
  {
    var harga_jual_distributor = $('#harga_jual_distributor').val();
    var harga_jual = $('#harga_jual').val();
    var margin = $('#margin').val();
    var harga_awal = $('#harga_awal').val();
    if(harga_jual ==  '')
    {
        $('#margin').val(0);
    }
    else
    {
    var a = harga_jual - harga_jual_distributor;
    $('#margin').val(a);
    }

  }
</script>
@endpush