@extends('layouts.template')
@section('content')
<title>Stok Saya | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Stok Saya</h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Stok</th>
                        <th>Harga Beli</th>
                        <th>Harga Jual</th>
                        <th>Margin</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($produk as $no=> $value)
                    <tr>
                        <td>{{++$no}}</td>
                        <td>{{$value->produk->nama_produk}}</td>
                        <td>{{$value->stok_reseller}}</td>
                        <td>{{$value->produk->harga_jual}}</td>
                        <td>{{$value->harga_jual}}</td>
                        <td>{{$value->harga_jual - $value->produk->harga_jual}}</td>
                        <td>
                            <a href="/stok_reseller/edit/{{$value->id}}" class="btn btn-primary putih btn-sm">Ubah</a>
                        </td>
                    @endforeach
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
