@extends('layouts.template')
@section('content')
<title>Edit Kategori | Kelola Penjualan</title>
@if( Session::get('gagal') !="")
            <div class='alert alert-danger'><center><b>{{Session::get('gagal')}}</b></center></div>        
@endif
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Data</h6>
    </div>
    <div class="card-body">
        
    <form action="/kategori/update" method="post">
    @csrf
        <div class="form-group">
            <label for="">Nama Kategori</label>
            <input type="hidden" name="id" value="{{$kategori->id}}">
            <input type="text" name="nama_kategori" value="{{$kategori->nama_kategori}}" class="form-control" required>
        </div>
        <hr>
        <div class="row">
            <div class="col-lg-3">
                    <button class='btn btn-custon-rounded-three btn-primary' name="tambah" type="submit"><i class='fa fa-file-text edu-informatio' aria-hidden='true'></i> Update</button>
                            <a href="/kategori" class="btn btn-danger">Kembali</a>
            </div>
        </div>
        <hr>
    </form>
    </div>
</div>

@endsection