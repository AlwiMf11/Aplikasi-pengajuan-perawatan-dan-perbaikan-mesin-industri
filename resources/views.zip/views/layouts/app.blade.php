<!doctype html>
<html lang="en">
<style>
.metismenu-icon{
    color: black !important;
}

#upload{
    display:none
}

</style>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
  
    </head>
     <!-- favicon
    ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/bootstrap.min.css')}}">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{url('/kialap/style.css')}}">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/responsive.css')}}">



@yield('content')
<!-- <script src="https://code.jquery.com/jquery-3.3.1.js"></script> -->

<!-- sweetalert confirm -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>




@stack('scripts')

<script>

$(function(){
    $("#upload_link").on('click', function(e){
        e.preventDefault();
        $("#upload:hidden").trigger('click');
    });
});

</script>

</html>
