<!doctype html>
<html class="no-js" lang="en">

<head>
<style>
@media screen and (min-width: 769px) {
    .logo-pro {
        display: none !important;
    }
}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
   color: white;
   text-align: center;
}
.btn-sm{
    font-size: 10px !important;
    color: white !important;
    font-weight: bold !important;
}
</style>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
        ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="{{url('assets/favicon.ico')}}">
    <!-- Google Fonts
        ============================================ -->
   <!-- <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet"> -->
   <!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet"> -->
    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/bootstrap.min.css')}}">
    <!-- chosen CSS
    ============================================ -->
    <link rel="stylesheet" href="{{url('kialap/css/chosen/bootstrap-chosen.css')}}">

    <!-- Bootstrap CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/font-awesome.min.css')}}">
    <!-- animate CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/animate.css')}}">
    <!-- meanmenu icon CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/meanmenu.min.css')}}">
    <!-- main CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/main.css')}}">
    <!-- educate icon CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/educate-custon-icon.css')}}">
   
    <!-- metisMenu CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/metisMenu/metisMenu.min.css')}}">
    <link rel="stylesheet" href="{{url('/kialap/css/metisMenu/metisMenu-vertical.css')}}">
    <!-- style CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/style.css')}}">
    <!-- responsive CSS
        ============================================ -->
    <link rel="stylesheet" href="{{url('/kialap/css/responsive.css')}}">
    <!-- modernizr JS
        ============================================ -->
    <script src="{{url('/kialap/js/vendor/modernizr-2.8.3.min.js')}}"></script>

    <!-- Datatable Server Side -->
    <link rel="stylesheet" href="{{url('kialap/css/dataTables.bootstrap4.min.css')}}"/>

<style>
    .disabled {
        pointer-events: none;
        color: currentColor;
        cursor: not-allowed;
        opacity: 0.5;
        text-decoration: none;
    }
</style>

<!-- style custom input file -->
<style>
.custom-file-input {
  color: transparent;
  width: 139px !important;
  height: 30px !important;
}
.custom-file-input::-webkit-file-upload-button {
  visibility: hidden;
}
.custom-file-input::before {
  content: 'Select some image';
  color: black;
  display: inline-block;
  background: -webkit-linear-gradient(top, #f9f9f9, #e3e3e3);
  border: 1px solid #999;
  border-radius: 3px;
  padding: 5px 8px;
  outline: none;
  white-space: nowrap;
  -webkit-user-select: none;
  cursor: pointer;
  text-shadow: 1px 1px #fff;
  font-weight: 700;
  font-size: 10pt;
}
.custom-file-input:hover::before {
  border-color: black;
}
.custom-file-input:active {
  outline: 0;
}
.custom-file-input:active::before {
  background: -webkit-linear-gradient(top, #e3e3e3, #f9f9f9); 
}

</style>
<!-- akhir css custom file -->



</head>

<body>
    <!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
    <!-- Start Left menu area -->
    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="javascript:void(0)"><img class="main-logo" src="{{url('kialap/logo/logo.png')}}" style="width:190px; height:80px;" /></a>
            </div>
           <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                         <li class="active">
                            <hr>
                        </li>
                        <li class="active">
                        
                        @if(Auth::user()->level == 'Admin')
                            <a href="/dashboard_admin" aria-expanded="false" class="{{ (Request::path() == '/dashboard_admin') ? 'active' : '' }}">
                        @else
                            <a href="/dashboard_reseller" aria-expanded="false" class="{{ (Request::path() == '/dashboard_reseller') ? 'active' : '' }}">
                        @endif
                                   <span class="educate-icon educate-home icon-wrap"></span>
                                   <span class="mini-click-non">Dashboard</span></a>
                        </li>
                        @if(Auth::user()->level == 'Admin')
                        
                        <li>
                            <a class="has-arrow" href="index.html" >
								   <span class="educate-icon educate-course icon-wrap"></span>
								   <span class="mini-click-non">Data Produk</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Produk" href="/produk" class="{{ (Request::path() == '/produk') ? 'active' : '' }}"><span class="mini-sub-pro">Produk</span></a></li>
                                <li><a title="Kategori" href="/kategori"><span class="mini-sub-pro">Kategori</span></a></li>
                                <li><a title="Satuan" href="/satuan"><span class="mini-sub-pro">Satuan</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="index.html" >
								   <span class="educate-icon educate-library icon-wrap"></span>
								   <span class="mini-click-non">Data Stok</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Kartu Stok" href="/kartu_stok_admin"><span class="mini-sub-pro">Kartu Stok</span></a></li>
                                <li><a title="Penyesuaian Stok" href="/penyesuaian_stok_admin"><span class="mini-sub-pro">Penyesuaian Stok</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="index.html" >
								   <span class="educate-icon educate-apps icon-wrap"></span>
								   <span class="mini-click-non">Data Order</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Permintaan Order" href="/permintaan_order"><span class="mini-sub-pro">Permintaan Order</span></a></li>
                                <li><a title="Order Pembelian" href="/terima_order_supplier"><span class="mini-sub-pro">Order Pembelian</span></a></li>
                                <li><a title="Order Penjualan" href="/order_penjualan_admin"><span class="mini-sub-pro">Order Penjualan</span></a></li>
                            </ul>
                        </li>
                       
                        <li>
                            <a class="has-arrow" href="index.html" >
								   <span class="educate-icon educate-student icon-wrap"></span>
								   <span class="mini-click-non">Data User</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="User Admin" href="/admin"><span class="mini-sub-pro">Admin</span></a></li>
                                <li><a title="User Reseller" href="/reseller"><span class="mini-sub-pro">Reseller</span></a></li>
                                <li><a title="User Supplier" href="/supplier"><span class="mini-sub-pro">Supplier</span></a></li>
                            </ul>
                        </li>
                        
                        @else
                        
                        <li>
                            <a href="/stok_reseller" aria-expanded="false" class="{{ (request()->is('stok_reseller*'))}}"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Stok Saya</span></a>
                        </li>
                        <li>
                            <a class="has-arrow" href="index.html" >
								   <span class="educate-icon educate-library icon-wrap"></span>
								   <span class="mini-click-non">Data Stok</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Kartu Stok" href="/kartu_stok/reseller"><span class="mini-sub-pro">Kartu Stok</span></a></li>
                                <li><a title="Penyesuaian Stok" href="/penyesuaian_stok/reseller"><span class="mini-sub-pro">Penyesuaian Stok</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="index.html" >
								   <span class="educate-icon educate-course icon-wrap"></span>
								   <span class="mini-click-non">Data Produk</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Produk" href="/produk"><span class="mini-sub-pro">Produk</span></a></li>
                                <li><a title="Kategori" href="/kategori"><span class="mini-sub-pro">Kategori</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="index.html" >
								   <span class="educate-icon educate-apps icon-wrap"></span>
								   <span class="mini-click-non">Data Order</span>
								</a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="javacript:void(0)" href="/order_penjualan_reseller" class="{{ (request()->is('order_penjualan_reseller'))}}"><span class="mini-sub-pro">Order Penjualan</span></a></li>
                                <li><a title="javacript:void(0)" href="/order_pembelian_reseller" class="{{ (request()->is('order_pembelian_reseller'))}}"><span class="mini-sub-pro">Order Pembelian</span></a></li>
                            </ul>
                        </li>
                        @endif


                        <li>
                            <a href="/my_profile" aria-expanded="false" class="{{ (request()->is('my_profile*'))}}"><span class="educate-icon educate-professor icon-wrap"></span> <span class="mini-click-non">Profil</span></a>
                        </li>
                     
                    </ul>
                </nav>
            </div>
        </nav>
    </div>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="javascript:void(0)"><img class="main-logo" src="{{url('kialap/logo/logo.png')}}" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
													<i class="educate-icon educate-nav"></i>
												</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                        <ul class="nav navbar-nav mai-top-nav">
                                            <li class="nav-item"><a href="#" class="nav-link">Makan Daging Sehat dan Berkualitas</a>
                                            </li>
                                        </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                    @if(Auth::user()->level !="Reseller")
                                                        @if(Auth::user()->foto == null)
                                                        <img src="{{url('/database/foto_profil/avatar-2.png')}}">
                                                        @else
                                                        <img src="{{url('/database/foto_profil/'. Auth::user()->foto)}}">
                                                        @endif
                                                        <span class="admin-name">{{Auth::user()->nama}}</span>
                                                        <i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
                                                    @else
                                                        @if(Auth::user()->reseller->foto == null)
                                                        <img src="{{url('/database/foto_profil/avatar-2.png')}}">
                                                        @else
                                                        <img src="{{url('/database/foto_profil/'. Auth::user()->reseller->foto)}}">
                                                        @endif
                                                        <span class="admin-name">{{Auth::user()->reseller->nama}}</span>
                                                        <i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
                                                    @endif

                                                    </a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        <li><a href="/my_profile"><span class="edu-icon edu-user-rounded author-log-ic"></span>My Profile</a>
                                                        </li>
                                                        <li>
                                                        <a href="{{ route('logout') }}"
                                                            onclick="event.preventDefault();
                                                            document.getElementById('logout-form').submit();">
                                                            <span class="edu-icon edu-locked author-log-ic"></span>Log Out
                                                        </a>

                                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                                            @csrf
                                                        </form>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li class="nav-item nav-setting-open"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="educate-icon educate-menu"></i></a>
<!-- 
                                                    <div role="menu" class="admintab-wrap menu-setting-wrap menu-setting-wrap-bg dropdown-menu animated zoomIn">
                                                        
                                                    </div> -->
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                    @if(Auth::user()->level == 'Admin')
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Data Produk <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="/produk">Produk</a></li>
                                                <li><a href="/kategori">Kategori</a></li>
                                                <li><a href="/satuan">Satuan</a></li>
                                            </ul>
                                        </li>
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Data Stok <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="/kartu_stok_admin">Kartu Stok</a></li>
                                                <li><a href="/penyesuaian_stok_admin">Penyesuaian Stok</a></li>
                                            </ul>
                                        </li>
                                        
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Data Order <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="/permintaan_order">Permintaan Order</a></li>
                                                <li><a href="/terima_order_supplier">Order Pembelian</a></li>
                                            </ul>
                                        </li>
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Data User <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="/admin">Admin</a></li>
                                                <li><a href="/reseller">Reseller</a></li>
                                            </ul>
                                        </li>
                                    @else
                                        <li><a href="/stok_reseller">Stok Saya</a></li>
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Data Produk <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="/produk">Produk</a></li>
                                                <li><a href="/kategori">Kategori</a></li>
                                                <li><a href="/satuan">Satuan</a></li>
                                            </ul>
                                        </li>
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Data Order <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                            <ul class="collapse dropdown-header-top">
                                                <li><a href="/order_penjualan_reseller">Order Penjualan</a></li>
                                                <li><a href="/order_pembelian_reseller">Order Pembelian</a></li>
                                            </ul>
                                        </li> 
                                    @endif
                                    
                                        <li><a href="/my_profile">My Profile</a></li>
                                       
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @include('sweetalert::alert')
        @yield('content')
<br><br>
        <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="footer-copy-right">
                            <p> ©  2020. Makan Daging Sehat dan Berkualitas</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- jquery
		============================================ -->
    <script src="{{url('kialap/js/vendor/jquery-1.12.4.min.js')}}"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="{{url('kialap/js/bootstrap.min.js')}}"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="{{url('kialap/js/jquery.meanmenu.js')}}"></script>
    <!-- sticky JS
		============================================ -->
    <script src="{{url('kialap/js/jquery.sticky.js')}}"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="{{url('kialap/js/metisMenu/metisMenu.min.js')}}"></script>
    <script src="{{url('kialap/js/metisMenu/metisMenu-active.js')}}"></script>
    <!-- plugins JS
		============================================ -->
    <script src="{{url('kialap/js/plugins.js')}}"></script>
    <!-- main JS
		============================================ -->
    <script src="{{url('kialap/js/main.js')}}"></script>


    <script src="{{url('kialap/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{url('kialap/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Datatable Server Side    
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script> -->
    <!-- chart -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script>
        $('.disabled').click(function(e){
        e.preventDefault();
        })
    </script>
    @stack('scripts')

</body>

</html>