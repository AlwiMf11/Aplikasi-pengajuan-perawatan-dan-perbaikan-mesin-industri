<!doctype html>
<html lang="en">
<style>
.metismenu-icon{
    color: black !important;
}

#upload{
    display:none
}

body{
    background-image: url("/assets/img/logo2.jpg");
}

</style>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
  
    </head>
     <!-- favicon
    ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/bootstrap.min.css')}}">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/font-awesome.min.css')}}">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/owl.carousel.css')}}">
    <link rel="stylesheet" href="{{url('assets/kialap/css/owl.theme.css')}}">
    <link rel="stylesheet" href="{{url('assets/kialap/css/owl.transitions.css')}}">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/animate.css')}}">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/normalize.css')}}">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/main.css')}}">
    <!-- morrisjs CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/morrisjs/morris.css')}}">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/scrollbar/jquery.mCustomScrollbar.min.css')}}">
    <!-- metisMenu CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/metisMenu/metisMenu.min.css')}}">
    <link rel="stylesheet" href="{{url('assets/kialap/css/metisMenu/metisMenu-vertical.css')}}">
    <!-- calendar CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/calendar/fullcalendar.min.css')}}">
    <link rel="stylesheet" href="{{url('assets/kialap/css/calendar/fullcalendar.print.min.css')}}">
    <!-- forms CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/form/all-type-forms.css')}}">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/style.css')}}">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="{{url('assets/kialap/css/responsive.css')}}">



@yield('content')
<script type="text/javascript" src="{{url('assets/arsitek/scripts/main.js')}}"></script></body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>

<!-- sweetalert confirm -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!-- modernizr JS
============================================ -->
<script src="{{url('assets/kialap/js/vendor/modernizr-2.8.3.min.js')}}"></script>
<!-- jquery
============================================ -->
<script src="{{url('assets/kialap/js/vendor/jquery-1.12.4.min.js')}}"></script>
<!-- bootstrap JS
============================================ -->
<script src="{{url('assets/kialap/js/bootstrap.min.js')}}"></script>
<!-- wow JS
============================================ -->
<script src="{{url('assets/kialap/js/wow.min.js')}}"></script>
<!-- price-slider JS
============================================ -->
<script src="{{url('assets/kialap/js/jquery-price-slider.js')}}"></script>
<!-- meanmenu JS
============================================ -->
<script src="{{url('assets/kialap/js/jquery.meanmenu.js')}}"></script>
<!-- owl.carousel JS
============================================ -->
<script src="{{url('assets/kialap/js/owl.carousel.min.js')}}"></script>
<!-- sticky JS
============================================ -->
<script src="{{url('assets/kialap/js/jquery.sticky.js')}}"></script>
<!-- scrollUp JS
============================================ -->
<script src="{{url('assets/kialap/js/jquery.scrollUp.min.js')}}"></script>
<!-- mCustomScrollbar JS
============================================ -->
<script src="{{url('assets/kialap/js/scrollbar/jquery.mCustomScrollbar.concat.min.js')}}"></script>
<script src="{{url('assets/kialap/js/scrollbar/mCustomScrollbar-active.js')}}"></script>
<!-- metisMenu JS
============================================ -->
<script src="{{url('assets/kialap/js/metisMenu/metisMenu.min.js')}}"></script>
<script src="{{url('assets/kialap/js/metisMenu/metisMenu-active.js')}}"></script>
<!-- tab JS
============================================ -->
<script src="{{url('assets/kialap/js/tab.js')}}"></script>
<!-- icheck JS
============================================ -->
<script src="{{url('assets/kialap/js/icheck/icheck.min.js')}}"></script>
<script src="{{url('assets/kialap/js/icheck/icheck-active.js')}}"></script>
<!-- plugins JS
============================================ -->
<script src="{{url('assets/kialap/js/plugins.js')}}"></script>
<!-- main JS
============================================ -->
<script src="{{url('assets/kialap/js/main.js')}}"></script>
<!-- tawk chat JS
============================================ -->
<script src="{{url('assets/kialap/js/tawk-chat.js')}}"></script>




@stack('scripts')

<script>

$(function(){
    $("#upload_link").on('click', function(e){
        e.preventDefault();
        $("#upload:hidden").trigger('click');
    });
});

</script>

</html>
