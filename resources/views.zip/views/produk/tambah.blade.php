@extends('layouts.template')
@section('content')
<style>
    
input[type=file]{
}

#idfoto{
    background-image:url('');
    background-size:cover;
    background-position: center;
    height: 100px; 
    width: 100px;
    border: 1px solid #bbb;
}

</style>
<title>Tambah Barang | Kelola Penjualan</title>
@if( Session::get('gagal') !="")
            <div class='alert alert-danger'><center><b>{{Session::get('gagal')}}</b></center></div>        
@endif
    @error('gambar')
    <div class="col-sm-12">
        <div class="col-sm-12">
            <div class="alert bg-danger">
                <strong class="text-white"> Gambar Produk Harus Berbentuk JPG / JPEG / PNG</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    @enderror 
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tambah Data</h6>
    </div>
    <div class="card-body">
    <form action="/produk/store" method="post" enctype="multipart/form-data">
        @csrf
            <div class="form-group">
                <label for="">Nama Produk @error('nama_produk') Nama produk tersebut telah digunakan @enderror</label>
                <input type="text" name="nama_produk" class="form-control" value="{{old('nama_produk')}}"  required>
            </div>
            <div class="form-group">
                <label for="">Deskripsi</label>
                <input type="text" name="deskripsi_produk" class="form-control" value="{{old('deskripsi_produk')}}"  required>
            </div>
            <div class="form-group">
                <label for="">Stok</label>
                <input type="number" name="stok" class="form-control" value="{{old('stok')}}"  required>
            </div>
            <div class="form-group">
                <label for="">Harga Jual</label>
                <input type="number" name="harga_jual" class="form-control" value="{{old('harga_jual')}}"  required>
            </div>
            
            <div class="form-group">
                <label for="">Harga Beli</label>
                <input type="number" name="harga_beli" class="form-control" value="{{old('harga_beli')}}"  required>
            </div>
            <div class="form-group">
                <label for="satuan_id">Satuan</label>
                <select data-placeholder="Pilih Satuan" name="satuan_id" class="form-control" tabindex="-1" required>
                <option value="" selected disable>~ Pilih Satuan ~</option>
                @foreach($satuan as $value)
                    <option value="{{$value->id}}">{{$value->nama_satuan}}</option>
                @endforeach
            </select>
            </div>
            <div class="form-group">
                <label for="kategori_id">Kategori</label>
                <select data-placeholder="Pilih kategori" name="kategori_id" class="form-control" tabindex="-1" required>
                <option value="" selected disable>~ Pilih kategori ~</option>
                @foreach($kategori as $value)
                    <option value="{{$value->id}}">{{$value->nama_kategori}}</option>
                @endforeach
            </select>
            </div>
            <div class="row">
                <div class="col-lg-8">
                    <label for="file">Upload Gambar :   </label>
                    <input required type="file" id='foto' name="gambar" class="form-control">
                </div>
                <div class="col-lg-4">
                    <div class="col-lg-4">
                        <div id='idfoto'></div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-3">
                        <button class='btn btn-custon-rounded-three btn-primary' name="tambah" type="submit"><i class='fa fa-file-text edu-informatio' aria-hidden='true'></i> Simpan</button>
                            <a href="/produk" class="btn btn-danger">Kembali</a>
                </div>
            </div>
            <hr>
        </form>
    </div>
</div>

@push('scripts')

<script>

document.getElementById('foto').addEventListener('change', readURL, true);
function readURL(){
   var file = document.getElementById("foto").files[0];
   var reader = new FileReader();
   reader.onloadend = function(){
      document.getElementById('idfoto').style.backgroundImage = "url(" + reader.result + ")";        
   }
   if(file){
      reader.readAsDataURL(file);
    }else{
    }
}

</script>
@endpush
@endsection