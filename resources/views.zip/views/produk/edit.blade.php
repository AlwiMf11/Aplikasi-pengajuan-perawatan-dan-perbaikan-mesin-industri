@extends('layouts.template')
@section('content')
<style>
    
.atur{
   height: 250px;
      width: 250px;
}
input[type=file]{
}

</style>

@if(Auth::user()->level=='Admin')
<title>Edit Barang | Kelola Penjualan</title>
@else
<title>Detail Barang | Kelola Penjualan</title>
@endif
@if( Session::get('gagal') !="")
            <div class='alert alert-danger'><center><b>{{Session::get('gagal')}}</b></center></div>        
@endif
<div class="card shadow mb-4">
    <div class="card-header py-3">
        @if(Auth::user()->level=='Admin')
        <h6 class="m-0 font-weight-bold text-primary">Edit Barang</h6>
        @else
        <h6 class="m-0 font-weight-bold text-primary">Detail Barang</h6>
        @endif
    </div>
    <div class="card-body">
        
    <form action="/produk/update" method="post" enctype="multipart/form-data">
        @csrf
        @foreach($produk as $value)
        <input type="hidden" name="id" value="{{$value->id}}">
        <div class="form-group">
                <label for="">Nama Barang @error('nama_produk') Nama produk tersebut telah digunakan @enderror</label>
                <input type="text" name="nama_produk" class="form-control" value="{{$value->nama_produk}}"  required>
            </div>
            <div class="form-group">
                <label for="">Deskripsi</label>
                <input type="text" name="deskripsi_produk" class="form-control" value="{{$value->deskripsi_produk}}"  required>
            </div>
            <div class="form-group">
                <label for="">Harga Jual</label>
                <input type="number" name="harga_jual" class="form-control" value="{{$value->harga_jual}}"  required>
            </div>
            
            @if(Auth::user()->level=='Admin')
            <div class="form-group">
                <label for="">Harga Beli</label>
                <input type="number" name="harga_beli" class="form-control" value="{{$value->harga_beli}}"  required>
            </div>
            @else
            @endif
            <div class="form-group">
                <label for="satuan_id">Satuan</label>
                
            @if(Auth::user()->level=='Admin')
                <select data-placeholder="Pilih Satuan" name="satuan_id" class="form-control" tabindex="-1" required>
            @else
                <select data-placeholder="Pilih Satuan" name="satuan_id" class="form-control" tabindex="-1" disabled>
            @endif
                <option value="" selected disable>~ Pilih Satuan ~</option>
                @foreach($satuan as $sat)
                    @if($value->satuan_id == $sat->id)
                    <option value="{{$sat->id}}" selected>{{$sat->nama_satuan}}</option>
                    @else
                    <option value="{{$sat->id}}">{{$sat->nama_satuan}}</option>
                    @endif
                @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="kategori_id">Kategori</label>
            @if(Auth::user()->level=='Admin')
                <select data-placeholder="Pilih kategori" name="kategori_id" class="form-control" tabindex="-1" required>
            @else
                <select data-placeholder="Pilih kategori" name="kategori_id" class="form-control" tabindex="-1" disabled>
            @endif
                <option value="" selected disable>~ Pilih kategori ~</option>
                @foreach($kategori as $sat)
                    @if($value->kategori_id == $sat->id)
                    <option value="{{$sat->id}}" selected>{{$sat->nama_kategori}}</option>
                    @else
                    <option value="{{$sat->id}}">{{$sat->nama_kategori}}</option>
                    @endif
                @endforeach
                </select>
            </div>
            
            @if(Auth::user()->level=='Admin')
            <span>Ubah Foto Barang ?</span>
            <label for="chkYes">
                <input type="radio" id="chkYes" name="chkPassPort" onclick="ShowHideDiv()" required />
                Ya
            </label>
            <label for="chkNo">
                <input type="radio" id="chkNo" name="chkPassPort" onclick="ShowHideDiv()" required />
                Tidak
            </label>
            @else
            @endif
            <hr />
            <div class="row">
                <div class="col-lg-8" id="hilang" style="display: none">
                    <input type='file' id="dvPassport" style="display: none" class="form-control" onchange="readURL(this);" name="gambar" value="{{$value->foto_produk}}" />
                </div>
            
                <div class="col-lg-4">
                    <label for="">Gambar Produk (JPG,JPEG,PNG) </label><br>
                    <img id="blah" class="atur" src="{{url('/database/foto_produk/'. $value->foto_produk )}}" alt="your image" />
                </div>
            </div>
            <hr>
            
            <div class="row">
                <div class="col-lg-3">
                        @if(Auth::user()->level=='Admin')
                        <button class='btn btn-custon-rounded-three btn-primary' type="submit"><i class='fa fa-file-text edu-informatio' aria-hidden='true'></i> Update</button>
                        @else
                        @endif
        </form>
                        @if(Auth::user()->level=='Admin')
                        <button class='btn btn-custon-rounded-three btn-danger' type="reset" value="Reset" onClick="javascript:history.back()"><i class='fa fa-times-circle edu-informatio' aria-hidden='true'></i> Batal</button>
                        @else
                        <button class='btn btn-custon-rounded-three btn-danger' type="reset" value="Reset" onClick="javascript:history.back()">Kembali</button>
                        @endif
                </div>
            </div>
            <hr>
        @endforeach
    </div>
</div>

@endsection
@push('scripts')

<script>
 function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
<script type="text/javascript">
    function ShowHideDiv() {
        var chkYes = document.getElementById("chkYes");
        var hilang = document.getElementById("hilang");
        var dvPassport = document.getElementById("dvPassport");
        if(chkYes.checked)
        {
            dvPassport.style.display = "block";
            hilang.style.display = "block";
            dvPassport.required = true;
        }
        else
        {
            dvPassport.style.display = "none";
            hilang.style.display = "none";
            dvPassport.required = false;
        }
        
    }
</script>
@endpush