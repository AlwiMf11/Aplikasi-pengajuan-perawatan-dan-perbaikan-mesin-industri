<table id="dataTable" class="table table-bordered" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Keterangan</th>
                <th>Nama Produk</th>
                <th>Db</th>
                <th>Kr</th>
                <th>Saldo</th>
            </tr>
        </thead>
        <tbody>
      
        @foreach ($kartu_stok as $i => $u)
            <tr>
                <td>{{++$i}}</td>   
                <td>{{$u->tgl}}</td>   
                <td>{{$u->keterangan}}</td>   
                <td>{{$u->produk->nama_produk}}</td>   
                <td>{{$u->db}}</td>   
                <td>{{$u->kr}}</td>   
                <td>{{$u->saldo}}</td>   
            </tr>
        @endforeach
        </tbody>
</table>