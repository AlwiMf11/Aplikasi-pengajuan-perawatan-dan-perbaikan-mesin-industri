@extends('layouts.template')
@section('content')
<title>Satuan | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">              
            @if(Auth::user()->level !='Admin')
            @else
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Data Satuan</h6>
            </div>
            @endif                         
            @if(Auth::user()->level !='Admin')
            @else
            <div class="col-md-6 text-right">
                <a href="/satuan/tambah" class="btn btn-primary btn-sm">Tambah Data</a>
            </div>
            @endif
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Satuan</th>
                        @if(Auth::user()->level !='Admin')
                        @else
                        <th>Action</th>
                        @endif
                    </tr>
                </thead>
                <tbody>
                    @foreach ($satuan as $i => $value)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$value->nama_satuan}}</td>
                        @if(Auth::user()->level=='Admin')
                        <td>
                        <a href="/satuan/edit/{{ $value->id}}" class="btn btn-primary btn-sm">Edit</a>
                        </td>
                        @else
                        @endif
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
