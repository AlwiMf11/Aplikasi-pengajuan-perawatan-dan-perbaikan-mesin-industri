@extends('layouts.template')
@section('content')
<title>Lihat Transaksi | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6>Nama Reseller : {{$order->reseller->nama}} </h6>
            </div>
            
            <div class="col-md-6 text-right">
                <h6>No Purchase Order : {{$order->kd_transaksi_pembelian}} </h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                <tr>
                    <th>Nama Produk</th>
                    <th>Deskripsi Produk</th>
                    <th>Jumlah Pesanan</th>
                    @if($order->status_order =='dikirim' || $order->status_order =='diterima' )
                    <th>Jumlah Pengiriman</th>
                    @else
                    @endif
                    <th>Harga</th>
                    <th>Sub Total</th>
                </tr>
                </thead>
                <tbody>
                    @foreach($orders as $value)
                    <tr>
                        <td>{{$value->produk->nama_produk}}</td>
                        <td>{{$value->produk->deskripsi_produk}}</td>
                        <td>{{$value->jumlah_pesanan}}</td>
                        @if($order->status_order =='dikirim' || $order->status_order =='diterima' )
                        <td>{{$value->jumlah_pengiriman}}</td>
                        @else
                        @endif
                        <td>@currency($value->produk->harga_jual)</td>
                        <td>@currency($value->sub_total)</td>
                    </tr>
                        @endforeach
                        <tr>
                        @if($order->status_order =='dikirim' || $order->status_order =='diterima' )
                        <td colspan="5" style="text-align:center !important;">Total</td>
                        @else
                        <td colspan="4" style="text-align:center !important;">Total</td>
                        @endif
                        <td>@currency($orders->sum('sub_total'))</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
