@extends('layouts.template')
@section('content')
<title>Tanggapi Transaksi | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">
            <div class="col-md-6">
                <h6>Nama Reseller : {{$order->reseller->nama}} </h6>
            </div>
            
            <div class="col-md-6 text-right">
                <h6>No Purchase Order : {{$order->kd_transaksi_pembelian}} </h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                <tr>
                    <th>Nama Produk</th>
                    <th>Deskripsi Produk</th>
                    <th>Stok Distributor</th>
                    <th>Jumlah Pesanan</th>
                    <th>Harga</th>
                    <th>Sub Total</th>
                </tr>
                </thead>
                <tbody>
                    <form action="/kirim_stok_reseller" id="form-semua" method="post">
                    <input type="hidden" name="id" value="{{$order->id_transaksi}}">
                    @csrf
                    @foreach($orders as $value)
                    <tr>
                        <td>{{$value->produk->nama_produk}}</td>
                        <td>{{$value->produk->deskripsi_produk}}</td>
                        <td>{{$value->produk->stok}}</td>
                        <td>{{$value->jumlah_pesanan}}</td>
                        <td>@currency($value->produk->harga_jual)</td>
                        <td>@currency($value->sub_total)</td>
                    </tr>
                        @endforeach
                        <tr>
                        <td colspan="5" style="text-align:center !important;">Total</td>
                        <td>@currency($orders->sum('sub_total'))</td>
                    </tr>
                </tbody>
            </table>
            @if($value->produk->stok < $value->jumlah_pesanan != '')
            <button class="btn btn-primary" disabled title="jumlah stok tidak boleh ada yang kurang dari pesanan">Kirim PO</button>
            <a href="/permintaan_order/pending/{{$order->id_transaksi}}" class="btn btn-warning" onclick="return confirm('Anda yakin ingin pending PO ini ?')" >Pending</a>
            <a href="/permintaan_order" class="btn btn-danger">Kembali</a>
            @else
            @if($order->status_order =='dikirim')
            <button class="btn btn-primary" disabled>Sudah Dikirim</button>
            <a href="/permintaan_order" class="btn btn-danger">Kembali</a>
            @else
            <button class="btn btn-primary" id="simpan">Kirim PO</button>
            @endif
            </form>
            @endif
        </div>
    </div>
</div>

@endsection
