@extends('layouts.template')
@section('content')
<title>Permintaan Order | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">              
            @if(Auth::user()->level !='Admin')
            @else
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Semua Permintaan Order</h6>
            </div>
            @endif
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                <tr>
                    <th>No</th>
                    <th>No SO</th>
                    <th>No PO</th>
                    <th>Nama Reseller</th>
                    <th>Tgl Pemesanan</th>
                    <th>Qty Barang</th>
                    <th>Nilai PO</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                @foreach($order as $key=> $value)
                <tr>
                    <td>{{++$key}}</td>
                    <td>{{$value->id_transaksi}}</td>
                    <td>{{$value->kd_transaksi_pembelian}}</td>
                    <td>{{$value->reseller->nama}}</td>
                    <td>{{$value->tgl_pemesanan}}</td>
                    <td>{{$value->qty_barang}}</td>
                    <td>{{$value->nilai_transaksi}}</td>
                    <td>
                    @if($value->status_order == 'terkirim')
                    <span class="pull label-purple label-3 label">Permintaan Order</span>
                    @elseif($value->status_order == 'dikirim')
                    <span class="pull label-purple label-3 label">Terkirim</span>
                    @elseif($value->status_order == 'pending')
                    <span class="pull label-purple label-3 label">Pending</span>
                    
                    @elseif($value->status_order == 'diterima')
                    <span class="pull label-purple label-3 label">Diterima</span>
                    @endif
                    </td>
                    <td>
                    @if($value->status_order == 'terkirim')
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-list"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a href="/permintaan_order/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Tanggapi</a>
                        <a href="/permintaan_order/lihat/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Lihat</a>
                        <a href="/permintaan_order/cetak/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Cetak</a>
                        </div>
                    </div>
                    @elseif($value->status_order == 'dikirim')
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-list"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a href="/permintaan_order/lihat/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Lihat</a>
                        <a href="/permintaan_order/cetak/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Cetak</a>
                        </div>
                    </div>
                    @elseif($value->status_order == 'diterima')
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-list"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a href="/permintaan_order/lihat/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Lihat</a>
                        <a href="/permintaan_order/cetak/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Cetak</a>
                        </div>
                    </div>
                    @elseif($value->status_order == 'pending')
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-list"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a href="/permintaan_order/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Tanggapi</a>
                        <a href="/permintaan_order/lihat/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Lihat</a>
                        <a href="/permintaan_order/cetak/{{$value->kd_transaksi_pembelian}}" class="dropdown-item">Cetak</a>
                        </div>
                    </div>
                    @endif
                    </td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
