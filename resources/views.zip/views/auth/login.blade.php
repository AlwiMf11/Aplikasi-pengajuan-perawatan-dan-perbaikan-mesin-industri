@extends('layouts.app')
<style>

	
/* body{
    background-image: url("bg.jpg") !important;
	background-size: cover !important;
	background-repeat: no-repeat !important;
} */
/* .back{
	background-color : #34614b !important;
}
.back2{
	background-color : #bad4c1 !important;
} */
</style>
  <link href="{{url('aset/css/sb-admin-2.min.css')}}" rel="stylesheet">
@section('content')
<title>Login | Kelola Penjualan</title>
<body class="bg-gradient-success">	
<div class="error-pagewrap">
	<div class="error-page-int">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3><br> Kelola Penjualan</h3>
				<p>Mengelola penjualan menjadi lebih mudah</p>
			</div>
		</div>
		<div class="content-error">
			<div class="hpanel">
				<div class="panel-body back2">
					<br>
                    <form method="POST" action="{{ route('login') }}">		
					@csrf
						<div class="form-group">
							<label class="control-label" for="username" >Username</label>
							<input type="text" placeholder="" title="Please enter you username" required="" value="" class="form-control{{ $errors->has('username') ? ' is-invalid' : '' }}" name="username" value="{{ old('username') }}">
						</div>
						
						<div class="form-group-inner">
							<div class="container-fluid">
								<div class="row">
									<label class="control-label">Password</label>
									<div class="input-group custom-go-button">
									<input type="password" class="form-control" id="myInput" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" value="{{ old('password') }}">
									<span onclick="myFunction()" class="input-group-btn"><button type="button" class="btn bg-primary"><i class="fa fa-eye" id="mata" style="height:18px;"></i></button></span>
								</div>
							</div>
						</div>
						<br>
						<button class="btn btn-block btn-primary">Login</button>
					</form>
				</div>
			</div>
		</div>
		<br>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 style="margin-top:10px !important;">Start Your Day with A Positive Thinking </h6>
			</div>
		</div>
	</div>   
</div>

</body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">

</script>
<script>
$('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})


$("#password").password('toggle');

function myFunction() {
  var x = document.getElementById("myInput");
  var z = document.getElementById("mata");
  if (x.type=== "password") {
    x.type = "text";
    $("#mata").toggleClass("fa-eye-slash");
  } else if (x.type === "text") {
    x.type = "password";
    $("#mata").removeClass("fa-eye-slash");
  }
  
}
</script>
@endsection
