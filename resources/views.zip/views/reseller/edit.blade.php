@extends('layouts.template')
@section('content')
<style>

.atur{
   height: 250px;
      width: 250px;
}
</style>
<title>Edit Data Reseller | Kelola Penjualan</title>
@if( Session::get('gagal') !="")
            <div class='alert alert-danger'><center><b>{{Session::get('gagal')}}</b></center></div>        
@endif
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Data Reseller</h6>
    </div>
    <div class="card-body">
    <!-- awal form -->
        @if( Session::get('gagal_semua') !="")
        <div class='alert alert-danger'><center><b>{{Session::get('gagal_semua')}}</b></center></div>        
        @endif

        <form action="/reseller/update" method="post" enctype="multipart/form-data">
        @csrf
        <input type="hidden" value="{{$ambil_user->id}}" name="id">
            <div class="form-group">
                <label for="">Nama : @error('nama') <span class="text-danger">{{$message}} </span> @enderror </label>
                <input type="text" name="nama" class="form-control" value="{{$ambil_user->reseller->nama}}" required>
            </div>
            <div class="form-group">
                <label for="">Alamat : @error('alamat') <span class="text-danger">{{$message}} </span> @enderror </label>
                <input type="text" name="alamat" class="form-control" value="{{$ambil_user->reseller->alamat}}" required>
            </div>
            <div class="form-group">
                <label for="">No Telp : @error('no_telp') <span class="text-danger">{{$message}} </span> @enderror </label>
                <input type="number" name="no_telp" class="form-control" value="{{$ambil_user->reseller->no_telp}}" required>
            </div>
            
            <div class="form-group">
                <label for="">Email : @error('email') <span class="text-danger">Email yang anda input sudah digunakan oleh user lain</span> @enderror </label>
                <input type="text" name="email" class="form-control" value="{{$ambil_user->email}}" required>
            </div>
            <span>Ubah Foto Reseller ?</span>
            <label for="chkYes">
                <input type="radio" id="chkYes" name="chkPassPort" onclick="ShowHideDiv()" required />
                Ya
            </label>
            <label for="chkNo">
                <input type="radio" id="chkNo" name="chkPassPort" onclick="ShowHideDiv()" required />
                Tidak
            </label>
            @error('foto') <span class="text-danger">File foto harus berbentuk JPG,JPEG,PNG</span> @enderror 
            <hr />
            <div class="row">
                <div class="col-lg-8" id="hilang" style="display: none">
                    <input type='file' id="dvPassport" style="display: none" class="form-control-file" onchange="readURL(this);" name="foto" value="{{$ambil_user->reseller->foto}}" />
                </div>
            
                <div class="col-lg-4">
                    <label for="">Foto Profil (JPG,JPEG,PNG) </label>
                    @if($ambil_user->reseller->foto == null)
                    <img class="atur" src="{{url('/database/foto_profil/avatar-2.png')}}">
                    @else
                    <img id="blah" class="atur" src="{{url('/database/foto_profil/'. $ambil_user->reseller->foto)}}">
                    @endif
                </div>
            </div>
            <hr>
            

            <hr>
            <div class="row">
                <div class="col-lg-3">
                        <button class='btn btn-custon-rounded-three btn-primary' name="tambah" type="submit"><i class='fa fa-file-text edu-informatio' aria-hidden='true'></i> Simpan</button>
                        <a href="/admin" class='btn btn-custon-rounded-three btn-danger'>Batal</a>
                </div>
            </div>
            <hr>
        </form>
    </div>
</div>

@endsection

@push('scripts')

<!-- chosen JS
============================================ -->
<script src="{{url('kialap/js/chosen/chosen.jquery.js')}}"></script>
<script src="{{url('kialap/js/chosen/chosen-active.js')}}"></script>
<script>
 function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
<script type="text/javascript">
    function ShowHideDiv() {
        var chkYes = document.getElementById("chkYes");
        var hilang = document.getElementById("hilang");
        var dvPassport = document.getElementById("dvPassport");
        if(chkYes.checked)
        {
            dvPassport.style.display = "block";
            hilang.style.display = "block";
            dvPassport.required = true;
        }
        else
        {
            dvPassport.style.display = "none";
            hilang.style.display = "none";
            dvPassport.required = false;
        }
        
    }
</script>
@endpush