@extends('layouts.template')
@section('content')
<title>Data Reseller | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">              
            @if(Auth::user()->level !='Admin')
            @else
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Data Reseller</h6>
            </div>
            
            <div class="col-md-6 text-right">
                <a href="/reseller/tambah" class="btn btn-custon-rounded-three btn-primary btn-sm">Tambah</a>
            </div>
            @endif
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No Telp</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($reseller as $i => $value)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$value->reseller->nama}}</td>
                        <td>{{$value->reseller->alamat}}</td>
                        <td>{{$value->reseller->no_telp}}</td>
                        <td>
                        <a href="/reseller/edit/{{$value->reseller->id}}" class="btn btn-custon-rounded-two btn-success putih btn-sm" style="color:white">Edit</a>
                        <a href="/reseller/show/{{$value->reseller->id}}" class="btn btn-custon-rounded-two btn-primary putih btn-sm" style="color:white">Show</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
