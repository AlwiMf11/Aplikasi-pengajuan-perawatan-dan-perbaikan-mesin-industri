@extends('layouts.template')
@section('content')
<title>Detail Data Admin | Kelola Penjualan</title>

<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
            @if($users->foto == null)
            <img src="{{url('/database/foto_profil//avatar-2.png')}}" alt="AdminLTE Logo" style='width:260px; height: 270px;'>
            @else
            <img src="{{url('/database/foto_profil/'.$users->foto)}}" alt="" style='width:260px; height: 270px;'>
            @endif
            </div>
        </div>
    </div>
    <div class="col-lg-8 ">
        <div class="card">
            <div class="card-header">
                <h6>Detail Data Admin</h6>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label for="nama">Nama</label>
                    <input type="text" class="form-control" value="{{$users->nama}}">
                </div>
                <div class="form-group">
                    <label for="alamat">Alamat</label>
                    <input type="text" class="form-control" value="{{$users->alamat}}">
                </div>
                <div class="form-group">
                    <label for="no_telp">No Telp</label>
                    <input type="text" class="form-control" value="{{$users->no_telp}}">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" value="{{$users->email}}">
                </div>
            </div>
        </div>
    </div>
</div>

<br>
@endsection
