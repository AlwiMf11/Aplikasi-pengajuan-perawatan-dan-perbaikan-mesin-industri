@extends('layouts.layout')

<title>Tambah Admin | Makan Daging</title>
<style>

@media screen and (min-width: 1024px) {
    .geser {
        margin-top: 100px;
    }
}

@media screen and (max-width: 729px) {
    .geser {
        margin-top: 50px;
    }
    
}

</style>

@section('content')
<div class="container-fluid mt-5 geser">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="product-payment-inner-st">
                <ul id="myTabedu1" class="tab-review-design">
                        
                    <li class="active"><a href="#description">Tambah Admin</a></li>
                </ul>
                <div id="myTabContent" class="tab-content custom-product-edit">
                    <div class="product-tab-list tab-pane fade active in" id="description">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="review-content-section">
                                    <div id="dropzone1" class="pro-ad addcoursepro">
                                    <!-- awal form -->
                                        @if( Session::get('gagal') !="")
                                        <div class='alert alert-danger'><center><b>{{Session::get('gagal')}}</b></center></div>        
                                        @endif

                                        <form action="/admin/store" method="post" enctype="multipart/form-data">
                                        @csrf
                                            <div class="form-group">
                                                <label for="">Nama  @error('nama') <span class="text-danger">{{$message}} </span> @enderror </label>
                                                <input type="text" name="nama" class="form-control" value="{{old('nama')}}" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="">alamat @error('alamat') <span class="text-danger">{{$message}} </span> @enderror </label>
                                                <input type="text" name="alamat" class="form-control" value="{{old('alamat')}}" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="">No Telp</label>
                                                <input type="number" name="no_telp" class="form-control" value="{{old('no_telp')}}" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="">Email @error('email') <span class="text-danger">Email sudah digunakan oleh user lain </span> @enderror</label>
                                                <input type="email" name="email" class="form-control" value="{{old('email')}}" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="">Foto @error('foto')<div class='alert alert-danger'><center><b>Gagal upload foto, File harus berbentuk jpg/png/jpeg</b></center></div>@enderror</label>
                                                <input type="file" name="foto" class="form-control" required>
                                            </div>

                                            <hr>
                                            <div class="row">
                                                <div class="col-lg-3">
                                                        <button class='btn btn-custon-rounded-three btn-primary' name="tambah" type="submit"><i class='fa fa-file-text edu-informatio' aria-hidden='true'></i> Simpan</button>
                                                        <button class='btn btn-custon-rounded-three btn-danger' type="reset" value="Reset" onClick="javascript:history.back()"><i class='fa fa-times-circle edu-informatio' aria-hidden='true'></i> Batal</button>
                                                </div>
                                            </div>
                                            <hr>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection