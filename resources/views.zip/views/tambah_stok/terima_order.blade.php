@extends('layouts.template')
@section('content')
<title>Terima Order | Kelola Penjualan</title>
<div class="card shadow mb-4">
    <div class="card-header py-3">    
        <div class="row">              
            @if(Auth::user()->level !='Admin')
            @else
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-primary">Data Order Pembelian</h6>
            </div>
            @endif                         
            @if(Auth::user()->level !='Admin')
            @else
            <div class="col-md-6 text-right">
                <a href="/order_pembelian_distributor" class="btn btn-custon-rounded-three btn-primary btn-sm"> <i class="fa fa-plus"></i> Buat Purchase Order Baru</a>
            </div>
            @endif
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="dataTable" class="table table-bordered" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>No Purchase Order</th>
                        <th>Tgl Order</th>
                        <th>Tgl Diterima</th>
                        <th>Nama Supplier</th>
                        <th>Qty Barang</th>
                        <th>Nilai PO</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($order as $i => $value)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$value->kd_transaksi_distributor}}</td>
                        <td>{{$value->tgl_pemesanan}}</td>
                        <td>{{$value->tgl_diterima}}</td>
                        <td>{{$value->supplier->nama}}</td>
                        <td>{{$value->qty_barang}}</td>
                        <td>{{$value->nilai_transaksi}}</td>
                        <td>{{$value->status_order}}</td>
                        <td>
                        @if($value->status_order == 'terkirim')
                        <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-list"></i>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="/terima_order_supplier/update/{{$value->kd_transaksi_distributor}}" onclick="return confirm('Apakah anda yakin untuk menerima order ini ?')">Terima</a>
                                <a class="dropdown-item" href="/terima_order_supplier/lihat/{{$value->kd_transaksi_distributor}}">Lihat</a>
                            </div>
                        </div>
                        @else
                        <a href="/terima_order_supplier/lihat/{{$value->kd_transaksi_distributor}}" class="btn btn-primary btn-sm" style="color:white"><i class="fas fa-eye"></i></a>
                        @endif
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
