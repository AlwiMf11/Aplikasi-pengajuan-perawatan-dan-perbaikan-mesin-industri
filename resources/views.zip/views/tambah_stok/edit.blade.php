@extends('layouts.layout')
@section('content')
<style>

@media screen and (min-width: 1024px) {
    .geser {
        margin-top: 100px;
    }
}

@media screen and (max-width: 729px) {
    .geser {
        margin-top: 50px;
    }
    
}

</style>
<title>Lihat Transaksi | Makan Daging</title>
<!-- star menu -->
<div class="product-sales-area mg-tb-30 geser">
    <div class="data-table-area mg-b-15">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sparkline13-list">
                        <div class="sparkline13-hd">
                            <div class="main-sparkline13-hd">
                            <div class="row">
                                <div class="col-md-6">
                                    <h1>Detail Transaksi</h1>
                                </div>
                                <div class="col-md-6 text-right">

                                

                                </div>
                            </div>
                                <!-- <hr>

                                <button class='btn btn-custon-rounded-three btn-primary'><i class='fa fa-plus edu-informatio' aria-hidden='true'></i> Tambah Data</button></a>
                                <hr> -->
                                <hr>
                            </div>
                        </div>
                        <div class="sparkline13-graph">
                            <div class=" custom-datatable-overright table-responsive">
                                <table id="example" class="table table-striped table-bordered dt-responsive" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Nama Produk</th>
                                                <th>Deskripsi</th>
                                                <th>Harga</th>
                                                <th>Kuantitas</th>
                                                <th>Sub Total</th>
                                                <th>Aksi</th>
                                             </tr>
                                             @foreach($order as $value)
                                            <tr>
                                                <td>{{$value->order_pembelian_detail->order_pembelian->produk->nama_produk}}</td>
                                                <td>{{$value->order_pembelian_detail->order_pembelian->produk->deskripsi_produk}}</td>
                                                <td>{{$value->order_pembelian_detail->order_pembelian->produk->harga_beli}}</td>
                                                <td>
                                                <input type="number" disabled name="jumlah_pesanan" id="jumlah_pesanan" value="{{$value->order_pembelian_detail->order_pembelian->jumlah_pesanan}}" class="form-control">
                                                <button onclick="buka()">Ubah</button>
                                                </td>
                                                <td>{{$value->order_pembelian_detail->order_pembelian->sub_total}}</td>
                                                <td>
                                                <a href="terima_order_supplier/update" class="btn btn-primary btn-sm">Update</a>
                                                </td>
                                            </tr>
                                             @endforeach
                                        </thead>
                                        <tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
@push('scripts')

<script>
    $(document).ready(function() {
    $('#example').DataTable();

    function buka()
    {
        $("#jumlah_pesanan").prop("disabled", false);
    }
} );
</script>

@endpush